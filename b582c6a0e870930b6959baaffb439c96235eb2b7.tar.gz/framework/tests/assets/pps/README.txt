PerProviderSubscription.xml - valid PPS XML file
PerProviderSubscription_DuplicateHomeSP.xml - containing multiple HomeSP node
PerProviderSubscription_DuplicateValue.xml - FriendlyName node contains multiple Value
PerProviderSubscription_MissingValue.xml - FriendlyName node is missing Value
PerProviderSubscription_MissingName.xml - HomeSP node is missing NodeName
PerProviderSubscription_InvalidNode.xml - FQDN node contains both Value and a child node
PerProviderSubscription_InvalidName.xml - FriendlyName node have a typo in its name
